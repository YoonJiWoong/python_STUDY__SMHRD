
// 스크립트 공간 할당 >> JS 쓰는 공간
document.getElementById("btn").addEventListener("click",function(){
    //클릭했을때 돌아가는 로직을 작성하는 공간
    document.getElementById("design").style.color="blue";
    document.getElementById("design").style.backgroundColor="yellow";
})
    

