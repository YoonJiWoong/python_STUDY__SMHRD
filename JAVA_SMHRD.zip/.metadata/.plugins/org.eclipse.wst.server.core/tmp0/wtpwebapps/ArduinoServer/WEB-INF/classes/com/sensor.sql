create table arduinosensor(
	mysensor number
)

insert into arduinosensor values(0);

select * from arduinosensor;