
public class _0908_Q2_77���ϱ�1_���ϱ� {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int sum = 0;
		for(int a=1,b=77; a<=77; a++,b--)
		{
			sum =sum+(a*b);
			
		}System.out.println(sum);
	}

}
