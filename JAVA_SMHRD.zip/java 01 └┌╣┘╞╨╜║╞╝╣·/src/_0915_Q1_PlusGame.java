import java.util.Random;

public class _0915_Q1_PlusGame {

	public static boolean plus(int num1,int num2,int num3){
		
		
		
		if(num3 == num1+num2) {
			System.out.println("SUCCESS!");
			return true;
		}else {
			System.out.println("Fail...");
			return false;
		}
		
	}
	
	
}
