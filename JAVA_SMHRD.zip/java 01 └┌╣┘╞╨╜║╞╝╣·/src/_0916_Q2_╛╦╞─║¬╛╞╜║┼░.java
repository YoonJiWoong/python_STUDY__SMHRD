
public class _0916_Q2_���ĺ��ƽ�Ű {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		char array[] = new char[26];
		for (int k = 65, a = 0; k <= 90; k++, a++) {
			array[a] = (char)k;
			System.out.println(array[a]+" ");
		}
		

	}

}
