
public class _0906_Q3_����� {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		@@@@*
//		@@@**
//		@@***
//		@****
//		*****
		for(int num1=5,num2=5; num1>=0 && num2>=1; num1--, num2--)
		{
		for(int i = num1; i>=0; i--)
		{
			System.out.print(" ");	
		}
		for(int i = num2; i<=5; i++)
		{
			System.out.print("*");
		}
		
		System.out.println();
		}
		
	}

}
