
public class ������2�� {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//2�� : 2*1=2 2*2=4 .... 2*9=18
		System.out.print("2�� : ");
		for (int num2 = 1; num2<=9; num2++)
		{
			System.out.print("2*"+ num2 + "="+ (2*num2)+" ");
		}
		}
	}


