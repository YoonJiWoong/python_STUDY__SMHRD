
public class �����2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//*****
		//****
		//***
		//**
		//*
		
		for(int num = 5; num>=1; num--) {
			for (int i = 1; i <=num; i++) {
				System.out.print("*");
			}
			System.out.println();
	}
	}
	}

