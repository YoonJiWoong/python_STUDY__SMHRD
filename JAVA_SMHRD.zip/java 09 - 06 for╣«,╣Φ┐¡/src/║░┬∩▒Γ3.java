
public class �����3 {

	public static void main(String[] args) {

//		@@@@*
//		@@@***
//		@@*****
//		@*******
//
//		*********
//		@*******
//		@@*****
	
//		@@@***
		
		for (int space=4, star=1; space>=1; space--,star+=2)
		{
		
		for (int i = 0; i < space; i++) {
			System.out.print("@");
		}
		for (int i = 0; i < star; i++)
			System.out.print("*");
		System.out.println();
		}
		
		
		
		
//		System.out.print("@@@");
//		System.out.print("***");
//		System.out.println();
//		
//		System.out.print("@@");
//		System.out.print("*****");
//		System.out.println();
//		
//		System.out.print("@");
//		System.out.print("*******");
//		System.out.println();
//		
		
	}

}
