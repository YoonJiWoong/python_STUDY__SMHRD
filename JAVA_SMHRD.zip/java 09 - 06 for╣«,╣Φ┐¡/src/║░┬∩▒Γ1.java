
public class �����1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// *
		// **
		// ***
		// ****
		// *****
		// �����丵 ���? -�ϴ� ¥��, ������ �����ؼ�, ����ȭ�ϱ�
		for (int num = 1; num <= 7; num++) {

			for (int i = 0; i <= 5; i++) {
				System.out.print("*"+"\t");
			}
			System.out.println();
		}
	}
}
		
		
		
//			for (int i=0; i<1; i++) {
//		System.out.print("*");
//		}
//		System.out.println();
//		for (int i=0; i<2; i++) {
//		System.out.print("*");
//		}
//		System.out.println();
//		
//		for (int i=0; i<3; i++) {
//		System.out.print("*");
//		}
//		System.out.println();
//		
//		for (int i=0; i<4; i++)
//		{
//		System.out.print("*");
//		}
//		System.out.println();
//			
//		for (int i=0; i<5; i++)
//		{
//		System.out.print("*");
//		}
//		System.out.println();
//		}

