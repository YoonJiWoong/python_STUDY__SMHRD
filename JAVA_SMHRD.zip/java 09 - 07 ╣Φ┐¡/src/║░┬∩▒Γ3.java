
public class �����3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// @ 2 1 0
		// * 1 3 5
		// @ 2 1 0

		for (int a1 = 5, b1 = 1; a1 >= 3; a1--, b1 += 2) {
			for (int a = 0; a < a1; a++) {
				System.out.print(" ");
			}
			for (int b = 0; b < b1; b++) {
				System.out.print("*");
			}
			for (int a = 0; a < a1; a++) {
				System.out.print(" ");
			}
			System.out.println();
		}
		//////////////////////////////////////////
		for (int a1 = 4, b1 = 3; b1 <= 8; a1--, b1 += 2) {
			for (int a = 0; a < a1; a++) {
				System.out.print(" ");
			}
			for (int b = 0; b < b1; b++) {
				System.out.print("*");
			}
			for (int a = 0; a < a1; a++) {
				System.out.print(" ");
			}
			System.out.println();
		}
		//////////////////////////////////
		for (int a1 = 4, b1 = 3; b1 <= 9; a1--, b1 += 2) {
			for (int a = 0; a < a1; a++) {
				System.out.print(" ");
			}
			for (int b = 0; b < b1; b++) {
				System.out.print("*");
			}
			for (int a = 0; a < a1; a++) {
				System.out.print(" ");
			}
			System.out.println();
		}
		///////////////////////////////////////////
		for (int a1 = 4, b1 = 3; b1 <= 11; a1--, b1 += 2) {
			for (int a = 0; a < a1; a++) {
				System.out.print(" ");
			}
			for (int b = 0; b < b1; b++) {
				System.out.print("*");
			}
			for (int a = 0; a < a1; a++) {
				System.out.print(" ");
			}
			System.out.println();
		}

	}

}
