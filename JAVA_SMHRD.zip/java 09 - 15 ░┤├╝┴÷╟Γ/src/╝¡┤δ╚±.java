
public class ������ {

	
		int hunger;
		boolean isAwake;
		int money = 500000;
		String hairStyle = "2��8";
		
		public void eatRiceNoodle(int amout) {
			hunger = amout * 100;
		}
		
		public void sleep() {
			isAwake = false;
		}
		
		public void getGift() {
			money -= 10000;
		}
		public void settingHair(String st) {
			hairStyle = st;
		}
		
		
	}


