
public class GameSimulator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		Game game1 = new Game();
		game1.isTurnoff();
		System.out.println(game1.isTurnOn);
		game1.gameColor("������");
		System.out.println(game1.gameColor);
		game1.isTurnoff();
		System.out.println(game1.isTurnOn);
		
		
	}

}
