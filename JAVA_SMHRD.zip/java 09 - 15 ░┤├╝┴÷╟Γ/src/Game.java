
public class Game {

	// TODO Auto-generated method stub
	boolean isTurnOn;
	String resolution;
	String gameColor;

	public void isTurnoff() {

		isTurnOn = !isTurnOn;

	}
	public void resolution(String a) {
		resolution = a;
	}
	public void gameColor(String color) {
		gameColor = color;
	}
	
	
}
