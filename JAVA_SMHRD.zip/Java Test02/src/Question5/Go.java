package Question5;

public class Go {
	
	public void go() {
		System.out.println("�λ갣��.");
	}
	
}
